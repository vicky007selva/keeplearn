<!DOCTYPE html>
<html>
<head>
	<title>Foundation Details</title>
</head>
<body>
<?php  
include("../login/header.php");
?>	
<div class="container">
	<img src="../image/edufound.png" style="width: 80%">
	<div class="jumbotron">
		<div class="container">
			<h1 class="text-center">Welcome to Fountation name</h1>
			<p>India is on the cusp of change. The country is marching into the 21st century, rightly proud of all its advancements in science and technology, its spectacular improvements in infrastructure and IT. And yet, we're weighed down by devastating inequalities, by a huge population that remains untouched by well- meaning acts like the Right to Education, and a large gender inequality. At Agaram, we want to make a difference in the lives of the millions who are not yet touched by education.</p>
		 <button class="btn btn-info btn-lg col-md-4 col-mx-4">Learn More</button>
		</div>
	</div>
</div>
<div class="container-fluid" style="height: 50%">
	<div class="jumbotron" style="background-color:black ;width: 100%">
		<div class="container">
		</div>
	</div>
</div>
</html>