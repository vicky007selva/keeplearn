<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Responsive Donar Page</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css">	
</head>
<body>
	<?php  
	include("../login/connection.php");
	include("../login/header.php")
	?>
	<section class="contact">
		<div class="content">
			<h2>DONAR</h2>
			<p>Here you can your see donar details .</p>
		</div>
		<div class="container">
			<div class="contactInfo">
				<div class="box">
					<div class="icon"><i class="fa fa-id-card" aria-hidden="true"></i></div>
						<div class="text">
							<?php
                                //$donar= $_SESSION['donar'];
                                $query = "SELECT * FROM found WHERE id='1'";

                              $res= mysqli_query($conn,$query);

                              $row = mysqli_fetch_assoc($res);
               	    		  	   ?>
							<h3>ID</h3>
							<p><?php echo $row['id']; ?></p>
						</div>
				</div>
				<div class="box">
					<div class="icon"><i class="fa fa-star" aria-hidden="true"></i></div>
						<div class="text">
							<h3>State</h3>
							<p><?php echo $row['STATE']; ?></p>
						</div>
				</div>
				<div class="box">
					<div class="icon"><i class="fa fa-circle-o" aria-hidden="true"></i></div>
						<div class="text">
							<h3>DISTRICT</h3>
							<p><?php echo $row['DISTRICT']; ?></p>
						</div>
				</div>	
				<div class="box">
					<div class="icon"><i class="fa fa-sitemap" aria-hidden="true"></i></div>
						<div class="text">
							<h3>ORGANIZATION_NAME</h3>
							<p><?php echo $row['ORGANIZATION_NAME']; ?></p>
						</div>
				</div>
				<div class="box">
					<div class="icon"><i class="fa fa-envelope" aria-hidden="true"></i></div>
						<div class="text">
							<h3>EMAIL</h3>
							<p><?php echo $row['EMAIL']; ?></p>
						</div>
				</div>
				<div class="box">
					<div class="icon"><i class="fa fa-address-book" aria-hidden="true"></i></div>
						<div class="text">
							<h3>ADDRESS</h3>
							<p><?php echo $row['ADDRESS']; ?></p>
						</div>
				</div>
				<div class="box">
					<div class="icon"><i class="fa fa-phone" aria-hidden="true"></i></div>
						<div class="text">
							<h3>PHONE_NUMBER</h3>
							<p><?php echo $row['PHONE_NUMBER']; ?></p>
						</div>
				</div>
				<div class="box">
					<div class="icon"><i class="fa fa-check-square-o" aria-hidden="true"></i></div>
						<div class="text">
							<h3>SCHEMES</h3>
							<p><?php echo $row['SCHEMES']; ?></p>
						</div>
				</div>
				<div class="box">
					<div class="icon"><i class="fa fa-user-circle" aria-hidden="true"></i></div>
						<div class="text">
							<h3>AUTHORIZED_PERSON</h3>
							<p><?php echo $row['AUTHORIZED_PERSON']; ?></p>
						</div>
				</div>		
		    </div>
		</div>
	</section>
</body>
</html>