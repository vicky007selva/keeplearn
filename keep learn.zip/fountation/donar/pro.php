<!DOCTYPE html>
<?php  
session_start();
include("../login/connection.php");
if(isset($_POST['create'])){
	$C_ID=$_POST['C_ID'];
	$Qualification=$_POST['Qualification'];
	$Occupation=$_POST['Occupation'];
    $Annual_Salary=$_POST['Annual_Salary'];
    $Amount_per_year=$_POST['Amount_per_year'];
	$error=array();
	if(empty($C_ID)){
		$error['ac']="Enter C_ID";
	}
	elseif (empty($Qualification)) {
		$error['ac']="Enter Qualification";
	}
	elseif (empty($Occupation)) {
		$error['ac']="Enter Occupation";
	}
	elseif (empty($Annual_Salary)) {
		$error['ac']="Enter Annual_Salary";
	}
	elseif (empty($Father_Qualification)) {
		$error['ac']="Enter Amount_per_year";
	}
	
	if(count($error)==0){
		$query="INSERT INTO `Student Family Details`(`C_ID`, `Qualification`, `Occupation`, `Annual_Salary`, `Amount_per_year`) VALUES ('','$C_ID','$Qualification','$Occupation','$Annual_Salary','$Amount_per_year',NOW(),'patient.jpg')";
		$res=mysqli_query($conn,$query);
		if($res){
			header('Location:patientlogin.php');
		}
		else{
			echo "<script>alert('failed')</script>";
		}
	}
}

?>
<html>
<head>
	<title>Donar profesional detailss</title>
</head>
<body>
<?php  
include("../login/header.php");
?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6 my-5 jumbotron">
				 <h5 class="text-center my-3">Donar Profeesional Details</h5>
				 <form method="post">
				 	<div class="form-group">
				 		<label>C_ID</label>
				 		<input type="text" name="c_id" class="form-control" autocomplete="off" placeholder="Enter C_ID">
				 	</div>
				 	<div class="form-group">
				 		<label>Qualification</label>
				 		<input type="text" name="quali" class="form-control" autocomplete="off" placeholder="Enter Qualification">
				 	</div>
				 	<div class="form-group">
				 		<label>Occupation</label>
				 		<input type="text" name="Occupa" class="form-control" autocomplete="off" placeholder="Enter Occupation">
				 	</div>
				 	<div class="form-group">
				 		<label>Annual_Salary</label>
				 		<input type="text" name="salary" class="form-control" autocomplete="off" placeholder="Enter Annual_Salary">
				 	</div>
				 	<div class="form-group">
				 		<label>Amount_per_year</label>
				 		<input type="text" name="amount" class="form-control" autocomplete="off" placeholder="Enter Amount_per_year">
				 	</div>
				 	<input type="submit" name="create" class="btn btn-success my-3" value="Create Account">
				 	<p>I already have an account <a href="patientlogin.php" >Click here.</a></p>
				 </form>
				 <ul class="pagination justify-content-middle">
    					<li class="page-item active">
      						<a class="page-link" href="../donar/login.php" tabindex="-1">Previous</a>
    					</li>
    				<li class="page-item"><a class="page-link" href="../donar/login.php">1</a></li>
   					<li class="page-item"><a class="page-link" href="../donar/account.php">2</a></li>
    				<li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item active">
                      <a class="page-link" href="../donar/account.php">Next</a>
                    </li>
                </ul>
			</div>
			<div class="col-md-3"></div>
		</div>
	</div>
</div>
</body>
</html>

