<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Students</title>
</head>
<body>
<?php  
include("../login/header.php");
?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
		<div class="col-md-2 " style="margin-left: -30px;">
			<?php
				include("sidenav.php");
				include("../login/connection.php");
			  ?>
		</div>
		<div class="col-md-10">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
						<h5 class="text-center">All Students</h5>
						<?php 
						//$_SESSION['donar']=$donar;
						$query="SELECT * FROM student";
					$res=mysqli_query($conn,$query);
					$output="
					
					<table class= 'table table-bordered'>
							<tr><th>S_Id</th>
							<th>Name</th>
							<th>Date Of Birth</th>
							<th>Gender</th>
							<th>Address</th>
							<th>City</th>
							<th>District</th>
							<th>State</th>
							<th>Pincode</th>
							<th>Mobile Number</th>
							<th >Physically Challenged</th>
					</tr>";
					if(mysqli_num_rows($res)<1){
						$output.="<tr><td colspan='2'   class=text-center >No New Donar</td></tr>";
					}
					else{
					while ($row=mysqli_fetch_assoc($res)) {
						$id=$row['id'];
						$username=$row['name'];
						$dob=$row['dob'];
						$gender=$row['gender'];
						$add=$row['address'];
						$city=$row['city'];
						$dis=$row['district'];
						$st=$row['state'];
						$pn=$row['pincode'];
						$mnum=$row['mobile'];
						$phy=$row['phy challenged'];
						$output.="
						<tr>
								<td>$id</td>
								<td>$username</td>
								<td>$dob</td>
								<td>$gender</td>
								<td>$add</td>
								<td>$city</td>
								<td>$dis</td>
								<td>$st</td>
								<td>$pn</td>
								<td>$mnum</td>
								<td>$phy</td>
						";
					}
					}
					$output.="<tr></tr>
                              </table>";
                         echo "$output";
						?>

					</div>
					<div class="col-md-6">
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</body>
</html>