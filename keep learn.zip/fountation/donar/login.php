<?php  
session_start();
?>
<?php  
include("../login/header.php");
?>
<?php  
include("../login/connection.php");
?>
<!DOCTYPE html>
<?php  
if(isset($_POST['login'])){
	$uname=$_POST['uname'];
	$password=$_POST['pass'];
	if (empty($uname)) {
		echo "<script>alert('Enter Username')</script>";
		echo '<style><div class="alert alert-success ">you successfully loged in</div></style>';
	}
	elseif (empty($password)) {
		echo "<script>alert('Enter password')</script>";
	}
	else if(!empty($uname) && !empty($password)){
		$query="SELECT * FROM donar WHERE Name='$uname' AND password='$password'";
		$res=mysqli_query($conn,$query);
		if(mysqli_num_rows($res)>=0){
			$_SESSION['donar']=$uname;
			echo "<script>alert('hi you login as donar')</script>";
			header("Location:../donar/index.php");
			exit(); 
		}else{
			echo "<script>alert('Invalid credintials')</script>";
		}
	}
}
?>
<html>
<head>
	<title>Donar Login Page</title>
</head>
<body>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6 my-5 jumbotron">
				 <h5 class="text-center my-3">Donar Login</h5>
				 <form action="" method="POST">
				 	<div class="form-group">
				 		<label>Username</label>
				 		<input type="text" name="uname" class="form-control" autocomplete="off" placeholder="Enter Username">
				 	</div>
				 	<div class="form-group">
				 		<label>Password</label>
				 		<input type="password" name="pass" class="form-control" autocomplete="off" placeholder="Enter Password">
				 	</div>
				 	<input type="submit" name="login" class="btn btn-success my-3"  value="Login">
				 	<a href="../student/index.php">.</a>
				 	<p><b>I dont have an account </b><a href="account.php" ><kbd class="text text-info">Click here.</kbd></a></p>
				 </form>
				 <code>&it;&gt;By clicking Next give your details&it;&gt;</code>
				   <ul class="pagination justify-content-middle">
    					<li class="page-item disabled">
      						<a class="page-link" href="#" tabindex="-1">Previous</a>
    					</li>
    				<li class="page-item"><a class="page-link" href="../donar/pro.php">1</a></li>
   					<li class="page-item"><a class="page-link" href="../donar/account.php">2</a></li>
    				<li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item active">
                      <a class="page-link" href="../donar/pro.php">Next</a>
                    </li>
                </ul>
			</div>
<div class="col-md-3">
 </div>
		</div>
	</div>
</div>
</body>
</html>
