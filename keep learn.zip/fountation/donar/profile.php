<?php  
session_start();
?>
<!DOCTYPE html>
<html>
<head>
     <title>Donar Profile</title>
</head>
<body>
     <?php
          include("../login/header.php");
          include("../login/connection.php");
     ?>

     <div class="container-fluid">
          <div class="col-md-12">
               <div class="row">
               <div class="col-md-2" style="margin-left: -30px">
                         <?php
                              include("../donar/sidenav.php");
                              $donar = $_SESSION['donar'];
                              $query="SELECT * FROM donar WHERE name='$donar'";
                              $res=mysqli_query($conn,$query);
                              while ($row=mysqli_fetch_array($res)) {
                              $sname=$row['Name'];
                             }
                         ?>
               </div>
               <div class="col-md-10">
                        <div class="col-md-12">
                         <div class="row">
                              <div class="col-md-6">

                              <h5>My profile</h5>
                                   <table class="table table-bordered">
                                        <?php
                                        $donar =$_SESSION['donar'];
                              $query="SELECT * FROM donar WHERE name='$donar'";
                              $res=mysqli_query($conn,$query);
                              $row=mysqli_fetch_array($res);
                               ?>
                                        <tr>
                                             <th colspan="2" class="text-center">My Details</th>
                                        </tr>
                                        <tr>
                                             <td>Id</td>
                                             <td>
                                                  <?php
                                                   echo $row['C_ID'];?>
                                                  </td>
                                        </tr>
                                        <tr>
                                             <td>Username</td>
                                             <td><?php echo $row['Name'];?></td>
                                        </tr>
                                        <tr>
                                             <td>Date Of Birth</td>
                                             <td><?php echo $row['D_O_B'];?></td>
                                        </tr>
                                        <tr>
                                             <td>Gender</td>
                                             <td>
                                                  <?php
                                                   echo $row['Gender'];?>
                                                  </td>
                                        </tr>
                                        <tr>
                                             <td>Address</td>
                                             <td><?php echo $row['Address'];?></td>
                                        </tr>
                                        <tr>
                                             <td>City</td>
                                             <td><?php echo $row['City'];?></td>
                                        </tr>
                                        <tr>
                                             <td>District</td>
                                             <td>
                                                  <?php
                                                   echo $row['District'];?>
                                                  </td>
                                        </tr>
                                        <tr>
                                             <td>State</td>
                                             <td><?php echo $row['State'];?></td>
                                        </tr>
                                        <tr>
                                             <td>Pincode</td>
                                             <td><?php echo $row['Pincode'];?></td>
                                        </tr>
                                        <tr>
                                             <td>Phone</td>
                                             <td>
                                                  <?php
                                                   echo $row['Mobile_num'];?>
                                                  </td>
                                        </tr>
                                        <tr>
                                             <td>Email</td>
                                             <td><?php echo $row['Mail_ID'];?></td>
                                        </tr>
                                   </table>



                              </div>
                              <div class="col-md-6">
                                   <h5 class="text-center">Change Username</h5>
                                   <?php
                                    if(isset($_POST['update']))
                                    {
                                        $uname=$_POST['uname'];

                                             if(empty($uname))
                                             {

                                             }
                                             else{
                                                  $student =$_SESSION['donar'];
                                                  $query="UPDATE donar SET name='$uname' WHERE username='$donar'";
                                                  $res=mysqli_query($conn,$query);
                                                  if($res)
                                                  {
                                                       $_SESSION['donar'] = $uname;


                                                  }
                                             }
                                    }


                                   ?>

                                   <form method="post">
                                        <label>Enter Username</label>
                                        <input type="text" name="uname" class="form-control"
                                        autocomplete="off" placeholder="Enter Username">
                                        <input type="submit" name="update" class="btn btn-info my-2" value="Update Username">
                                   </form>
                                        <?php
                                             if(isset($_POST['change']))
                                             {
                                                  $old=$_POST['old_pass'];
                                                  $new=$_POST['new_pass'];
                                                  $con=$_POST['con_pass'];
                                                  $q="SELECT * FROM student";
                                                  $re = mysqli_query($conn,$q);
                                                  $row =mysqli_fetch_array($re);
                                                  if(empty($old))
                                                  {
                                                       echo "<script>alert('Enter old 
                                                       password')</script>";
                                                  }
                                                  else if(empty($new))
                                                  {
                                                       echo "<script>alert('Enter New
                                                       password')</script>";
                                                  }
                                                  else if($con != $new)
                                                  {
                                                  echo "<script>alert('Both password do not 
                                                  match')</script>";
                                                  }
                                                  else if($old != $row['password'])
                                                  {
                                                       echo "<script>alert('check the password')</script>";
                                                  }
                                                  else
                                                  {
                                                       $query ="UPDATE student SET password='$new'
                                                       WHERE username='$Doctor'";
                                                       mysqli_query($conn,$query);
                                                  }
                                             }
                                        ?>
                                        <button class="btn btn-success"><a href="../donar/location.php">Location Verication</a></button>
                                   <h5 class="my-4 text-center">Change Password</h5>
                                   <form method="post">
                                        <label>Old Password</label>
                                        <input type="password" name="old_pass" class="
                                        form-control" autocomplete="off" placeholder="Enter old Password">
                                        <label>New Password</label>
                                        <input type="password" name="new_pass" class="
                                        form-control" autocomplete="off" placeholder="Enter New Password">
                                        <label>Confirm Password</label>
                                        <input type="password" name="con_pass" class="
                                        form-control" autocomplete="off" placeholder="Enter Confirm Password">
                                        <input type="submit" name="change" class="btn btn-info
                                        my-2"
                                        value="Change Password">
                              </div>      
                         </div>
                        </div>
               </div>
               </div>
          </div>
     </div>    


</body>
</html>