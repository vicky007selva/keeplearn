<?php  
session_start();
?>
<!DOCTYPE html>

<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Contact Us</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css">	
</head>
<body>
<?php  
include("../login/connection.php");
include("../login/header.php");
	?>
	<section class="contact">
		<div class="content">
			<h2>Contact Us</h2>
			<p>this is our contact page.</p>
		</div>
		<div class="container">
			<div class="contactInfo">
				<div class="box">
					<div class="icon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
						<div class="text">
							<?php
                                      $donar= $_SESSION['donar'];
                                      $query = "SELECT * FROM donar WHERE Name='$donar'";

                              $res= mysqli_query($conn,$query);

                              $row = mysqli_fetch_assoc($res);
               	    		  	   ?>
							<h3><?php echo $row['Address'];    ?></h3>
							<h3><?php echo $row['City']; ?></h3><h3><?php echo $row['District']; 
							   ?></h3>
							   <h3><?php echo $row['Pincode'];    ?></h3>
						</div>
				</div>
				<div class="box">
					<div class="icon"><i class="fa fa-phone" aria-hidden="true"></i></div>
						<div class="text">
							<h3>Phone</h3>
							<h3><?php echo $row['Mobile_num'];    ?></h3>
						</div>
				</div>
				<div class="box">
					<div class="icon"><i class="fa fa-envelope" aria-hidden="true"></i></div>
						<div class="text">
							<h3>Email</h3>
							<h3><?php echo $row['Mail_ID'];    ?></h3>
						</div>
				</div>	
		     </div>
		     <div class="contactForm">
		     	<form>
		     		<h2>Send Message</h2>
		     		<div class="inputBox">
		     			<input type="text" name="" required="">
		     			<span>Full Name</span>
		     		</div>
		     		<div class="inputBox">
		     			<input type="text" name="" required="">
		     			<span>Email</span>
		     		</div>
		     		<div class="inputBox">
		     			<textarea required="required"></textarea>
		     			<span>Type your Message...</span>
		     		</div>
		     		<div class="inputBox">
		     			<input type="submit" name="" required="send">
		     		</div>
		     	</form>
		     </div>

		   </div>
	</section>
</body>
</html>