<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
				<!--sidenav-->
				<div class="list-group bg-dark" style="height:90vh ">
					<a href="index.php" class="list-group-item list-group-item-action bg-dark text-center text-warning">Dashboard</a>
					<a href="profile.php" class="list-group-item list-group-item-action bg-dark text-center text-warning">Profile</a>
					<a href="../donar/foundation.php" class="list-group-item list-group-item-action bg-dark text-center text-warning">Fountation Details</a>
					<a href="students.php" class="list-group-item list-group-item-action bg-dark text-center text-warning">Students</a>
					<a href="../donar/index1.php" class="list-group-item list-group-item-action bg-dark text-center text-warning">Contact Details</a>
				</div>

</body>
</html>