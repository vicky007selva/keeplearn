<?php  
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Student Profile</title>
</head>
<body>
	<?php
		include("../login/header.php");
		include("../login/connection.php");
	?>

	<div class="container-fluid">
		<div class="col-md-12">
			<div class="row">
               <div class="col-md-2" style="margin-left: -30px">
               		<?php
               			include("../student/sidenav.php");
               			$student = $_SESSION['student'];
                              $query="SELECT * FROM student WHERE name='$student'";
                              $res=mysqli_query($conn,$query);
                              while ($row=mysqli_fetch_array($res)) {
                              $sname=$row['name'];
                             }
               		?>
               </div>
               <div class="col-md-10">
               	    <div class="col-md-12">
               	    	<div class="row">
               	    		<div class="col-md-6">

               	    		<h5>My profile</h5>
               	    			<table class="table table-bordered">
                                        <?php
                                        $student =$_SESSION['student'];
                              $query="SELECT * FROM student WHERE name='$student'";
                              $res=mysqli_query($conn,$query);
                              $row=mysqli_fetch_array($res);
                               ?>
               	    				<tr>
               	    					<th colspan="2" class="text-center">My Details</th>
               	    				</tr>
               	    				<tr>
               	    					<td>Id</td>
               	    					<td>
                                                  <?php
                                                   echo $row['id'];?>
                                                  </td>
               	    				</tr>
               	    				<tr>
               	    					<td>Username</td>
               	    					<td><?php echo $row['name'];?></td>
               	    				</tr>
               	    				<tr>
               	    					<td>Password</td>
               	    					<td><?php echo $row['dob'];?></td>
               	    				</tr>
               	    				<tr>
               	    					<td>Phone Number</td>
               	    					<td><?php echo $row['gender'];?></td>
               	    				</tr>
               	    				<tr>
               	    					<td>Email</td>
               	    					<td><?php echo $row['first graduate'];?></td>
               	    				</tr>
                                        <tr>
                                             <td>Email</td>
                                             <td><?php echo $row['community'];?></td>
                                        </tr>
                                        <tr>
                                             <td>Email</td>
                                             <td><?php echo $row['religion'];?></td>
                                        </tr>
                                        <tr>
                                             <td>Email</td>
                                             <td><?php echo $row['nationality'];?></td>
                                        </tr>
                                        <tr>
                                             <td>Email</td>
                                             <td><?php echo $row['aadhar'];?></td>
                                        </tr>
                                        <tr>
                                             <td>Email</td>
                                             <td><?php echo $row['mobile'];?></td>
                                        </tr>
                                        <tr>
                                             <td>Email</td>
                                             <td><?php echo $row['address'];?></td>
                                        </tr>
                                        <tr>
                                             <td>Email</td>
                                             <td><?php echo $row['city'];?></td>
                                        </tr>
                                        <tr>
                                             <td>Email</td>
                                             <td><?php echo $row['state'];?></td>
                                        </tr>
                                        <tr>
                                             <td>Email</td>
                                             <td><?php echo $row['pincode'];?></td>
                                        </tr>
               	    			</table>



               	    		</div>
               	    		<div class="col-md-6">
               	    			<h5 class="text-center">Change Username</h5>
               	    			<?php
               	    			 if(isset($_POST['update']))
               	    			 {
               	    			 	$uname=$_POST['uname'];

               	    			 		if(empty($uname))
               	    			 		{

               	    			 		}
               	    			 		else{
                                                  $student =$_SESSION['student'];
               	    			 			$query="UPDATE student SET name='$uname' WHERE username='$student'";
               	    			 			$res=mysqli_query($conn,$query);
               	    			 			if($res)
               	    			 			{
               	    			 				$_SESSION['student'] = $uname;


               	    			 			}
               	    			 		}
               	    			 }


               	    			?>

               	    			<form method="post">
               	    				<label>Enter Username</label>
               	    				<input type="text" name="uname" class="form-control"
               	    				autocomplete="off" placeholder="Enter Username">
               	    				<input type="submit" name="update" class="btn btn-info my-2" value="Update Username">
               	    			</form>
               	    				<?php
               	    					if(isset($_POST['change']))
               	    					{
               	    						$old=$_POST['old_pass'];
               	    						$new=$_POST['new_pass'];
               	    						$con=$_POST['con_pass'];
               	    						$q="SELECT * FROM student";
               	    						$re = mysqli_query($conn,$q);
               	    						$row =mysqli_fetch_array($re);
               	    						if(empty($old))
               	    						{
               	    							echo "<script>alert('Enter old 
               	    							password')</script>";
               	    						}
               	    						else if(empty($new))
               	    						{
               	    							echo "<script>alert('Enter New
               	    							password')</script>";
               	    						}
               	    						else if($con != $new)
               	    						{
               	    						echo "<script>alert('Both password do not 
               	    						match')</script>";
               	    						}
               	    						else if($old != $row['password'])
               	    						{
               	    							echo "<script>alert('check the password')</script>";
               	    						}
               	    						else
               	    						{
               	    							$query ="UPDATE student SET password='$new'
               	    							WHERE username='$Doctor'";
               	    							mysqli_query($conn,$query);
               	    						}
               	    					}
               	    				?>
               	    			<h5 class="my-4 text-center">Change Password</h5>
               	    			<form method="post">
               	    				<label>Old Password</label>
               	    				<input type="password" name="old_pass" class="
               	    				form-control" autocomplete="off" placeholder="Enter old Password">
               	    				<label>New Password</label>
               	    				<input type="password" name="new_pass" class="
               	    				form-control" autocomplete="off" placeholder="Enter New Password">
               	    				<label>Confirm Password</label>
               	    				<input type="password" name="con_pass" class="
               	    				form-control" autocomplete="off" placeholder="Enter Confirm Password">
               	    				<input type="submit" name="change" class="btn btn-info
               	    				my-2"
               	    				value="Change Password">
               	    		</div>      
               	    	</div>
               	    </div>
               </div>
			</div>
		</div>
	</div>	


</body>
</html>