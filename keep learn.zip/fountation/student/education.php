<!DOCTYPE html>
<?php 
session_start();
include("../login/connection.php");
if(isset($_POST['create'])){
	$Student_ID=$_POST['Student_ID'];
	$Qualification=$_POST['Qualification'];
	$Year_of_passing=$_POST['Year_of_passing'];
	$School_name=$_POST['School_name'];
	$Town=$_POST['Town'];
	$District=$_POST['District'];
	$State=$_POST['State'];
    $Pincode=$_POST['Pincode'];
    $Mark_Percentage=$_POST['Mark_Percentage'];
    $Applied_Course=$_POST['Applied_Course'];
    $College_name=$_POST['College_name'];
    $University=$_POST['University'];
    $Admission_Status=$_POST['Admission_Status'];
    $Fee_Structure=$_POST['Fee_Structure'];
    $Password=$_POST['Password'];
	$error=array();
	if(empty($Student_ID)){
		$error['ac']="Enter Student_ID";
	}
	elseif (empty($Qualification)) {
		$error['ac']="Enter Qualification";
	}
	elseif (empty($Year_of_passing)) {
		$error['ac']="Enter Year_of_passing";
	}
	elseif (empty($School_name)) {
		$error['ac']="Enter School_name";
	}
	elseif (empty($Town)) {
		$error['ac']="Enter Town";
	}
	elseif (empty($District)) {
		$error['ac']="Enter District";
	}
	elseif (empty($State)) {
		$error['ac']="Select State";
	}
	elseif (empty($Pincode)) {
		$error['ac']="Enter Pincode";
	}
	elseif (empty($Mark_Percentage)) {
		$error['ac']="Enter Mark_Percentage";
	}
	elseif (empty($Applied_Course)) {
		$error['ac']="Enter Applied_Course";
	}
	elseif (empty($College_name)) {
		$error['ac']="Select College_name";
	}
	elseif (empty($University)) {
		$error['ac']="Enter University";
	}
	elseif (empty($Admission_Status)) {
		$error['ac']="Enter Admission_Status";
	}
	elseif (empty($Fee_Structure)) {
		$error['ac']="Enter Fee_Structure";
	}
	elseif (empty($Password)) {
		$error['ac']="Enter Password";
	}
	if(count($error)==0){
		$query="INSERT INTO `Student Educational Details`(`Student_ID`, `Qualification`, `Year_of_passing`, `School_name`, `Town`, `District`, `State`, `Pincode`, `Mark_Percentage`, `Applied_Course`, `College_name`,'University','Admission_Status','Fee_Structure','Password') VALUES ('','$Student_ID','$Qualification','$Year_of_passing','$School_name','$Town','$District','$State',$Pincode','$Mark_Percentage','$Applied_Course','$College_name','$University',  '$Admission_Status','$Fee_Structure','$Password',NOW(),'patient.jpg')";
		$res=mysqli_query($conn,$query);
		if($res){
			header('Location:patientlogin.php');
		}
		else{
			echo "<script>alert('failed')</script>";
		}
	}
}

?>
<html>
<head>
	<title>Educational Detailss</title>
</head>
<body>
<?php  
include("../login/header.php");
?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6 my-5 jumbotron">
				 <h5 class="text-center my-3">Educational Details</h5>
				 <form method="post">
				 	<div class="form-group">
				 		<label>Student_ID</label>
				 		<input type="number" name="stu_id" class="form-control" autocomplete="off" placeholder="Enter Student_ID">
				 	</div>
				 	<div class="form-group">
				 		<label>Qualification</label>
				 		<input type="text" name="qual" class="form-control" autocomplete="off" placeholder="Enter Qualification">
				 	</div>
				 	<div class="form-group">
				 		<label>Year_of_passing</label>
				 		<input type="number" name="uname" class="form-control" autocomplete="off" placeholder="Enter Year_of_passing">
				 	</div>
				 	<div class="form-group">
				 		<label>School_name</label>
				 		<input type="text" name="school" class="form-control" autocomplete="off" placeholder="Enter School_name">
				 	</div>
				 	<div class="form-group">
				 		<label>Town</label>
				 		<input type="text" name="town" class="form-control" autocomplete="off" placeholder="Enter Phone Number">
				 	</div>
				 	<div class="form-group">
				 		<label>District</label>
				 		<input type="text" name="dist" class="form-control" autocomplete="off" placeholder="Enter District">
				 	</div>
				 	<div class="form-group">
				 		<label>State</label>
				 		<input type="text" name="stat" class="form-control" autocomplete="off" placeholder="Enter State">
				 	</div>
				 	<div class="form-group">
				 		<label>Pincode</label>
				 		<input type="number" name="pin" class="form-control" autocomplete="off" placeholder="Enter Pincode">
				 	</div>
				 	<div class="form-group">
				 		<label>Mark_Percentage</label>
				 		<input type="number" name="mark" class="form-control" autocomplete="off" placeholder="Enter Mark_Percentage">
				 	</div>
				 	<div class="form-group">
				 		<label>Applied_Course</label>
				 		<input type="text" name="applied" class="form-control" autocomplete="off" placeholder="Enter Applied_Course">
				 	</div>
				 	<div class="form-group">
				 		<label>College_name</label>
				 		<input type="text" name="college" class="form-control" autocomplete="off" placeholder="Enter College_name">
				 	</div>
				 	<div class="form-group">
				 		<label>University</label>
				 		<input type="text" name="univ" class="form-control" autocomplete="off" placeholder="Enter University">
				 	</div>
				 	<div class="form-group">
				 		<label>Admission_Status</label>
				 		<input type="text" name="admissionstat" class="form-control" autocomplete="off" placeholder="Enter Admission_Status">
				 	</div>
				 	<div class="form-group">
				 		<label>Fee_Structure</label>
				 		<input type="number" name="fee" class="form-control" autocomplete="off" placeholder="Enter Fee_Structure">
				 	</div>
				 	<input type="submit" name="create" class="btn btn-success my-3" value="Create Account">
				 	<p>I already have an account <a href="patientlogin.php" >Click here.</a></p>
				 </form>
				 <ul class="pagination justify-content-middle">
    					<li class="page-item active">
      						<a class="page-link" href="../student/login.php" tabindex="-1">Previous</a>
    					</li>
    				<li class="page-item"><a class="page-link" href="../student/login.php">1</a></li>
   					<li class="page-item"><a class="page-link" href="../student/family.php">2</a></li>
    				<li class="page-item"><a class="page-link" href="../student/account.php">3</a></li>
                    <li class="page-item active">
                      <a class="page-link" href="../student/family.php">Next</a>
                    </li>
                </ul>
			</div>
			<div class="col-md-3"></div>
		</div>
	</div>
</div>
</body>
</html>

