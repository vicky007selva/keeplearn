<!DOCTYPE html>
<?php  
session_start();
include("../login/connection.php");
if(isset($_POST['create'])){
	$did=$_POST['did'];
	$sname=$_POST['sname'];
	$pass=$_POST['pass'];
	$dob=$_POST['dob'];
	$phone=$_POST['phone'];
	$gender=$_POST['gender'];
	$blood=$_POST['blood'];
	$phy=$_POST['phy'];
	$first=$_POST['first'];
	$com=$_POST['com'];
	$rel=$_POST['rel'];
	$mom=$_POST['mom'];
	$anum=$_POST['anum'];
	$nation=$_POST['nation'];
	$add=$_POST['add'];
	$city=$_POST['city'];
	$dis=$_POST['dis'];
	$st=$_POST['st'];
	$pin=$_POST['pin'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$error=array();
	if(empty($did)){
		$error['ac']="Enter Firstname";
	}
	elseif (empty($sname)) {
		$error['ac']="Enter Firstname";
	}
	elseif (empty($pass)) {
		$error['ac']="Enter Firstname";	
	}
	elseif (empty($dob)) {
		$error['ac']="Enter email";
	}
	elseif (empty($phone)) {
		$error['ac']="Enter Phone";
	}
	elseif (empty($gender)) {
		$error['ac']="Select gender";
	}
	elseif (empty($blood)) {
		$error['ac']="Select country";
	}
	elseif (empty($phy)) {
		$error['ac']="Enter Password";
	}
	elseif (empty($first)) {
		$error['ac']="Enter Conform Password";
	}
	elseif (empty($com)) {
		$error['ac']="Enter Conform Password";
	}
	elseif (empty($rel)) {
		$error['ac']="Enter Conform Password";
	}
	elseif (empty($mom)) {
		$error['ac']="Enter Conform Password";
	}
	elseif (empty($anum)) {
		$error['ac']="Enter Conform Password";
	}
	elseif (empty($nation)) {
		$error['ac']="Enter Conform Password";
	}
	elseif (empty($add)) {
		$error['ac']="Enter Conform Password";
	}
	elseif (empty($city)) {
		$error['ac']="Enter Conform Password";
	}
	elseif (empty($dis)) {
		$error['ac']="Enter Conform Password";
	}
	elseif (empty($st)) {
		$error['ac']="Enter Conform Password";
	}
	elseif (empty($pin)) {
		$error['ac']="Enter Conform Password";
	}
	elseif (empty($email)) {
		$error['ac']="Enter Conform Password";
	}
	elseif (empty($phone)) {
		$error['ac']="Enter Conform Password";
	}
	if(count($error)==0){
		$query="INSERT INTO `student`(`id`, `name`, `dob`, `gender`, `language`, `blood`, `phy challenged`, `first graduate`, `community`, `religion`, `nationality`, `aadhar`, `mobile`, `address`, `city`, `district`, `state`, `pincode`) VALUES ('','$sname','$dob','$gender','$mom','$blood','$phy','$first','$com','$rel','$nation','$anum','$phone','$add','$city','$dis','$st','$pin')";
		$res=mysqli_query($conn,$query);
		if($res){
			header('Location:../student/login.php');
		}
		else{
			echo "<script>alert('failed')</script>";
		}
	}
}

?>
<html>
<head>
	<title>Create Account</title>
</head>
<body>
<?php  
include("../login/header.php");
?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6 my-5 jumbotron">
				 <h5 class="text-center my-3">Create Account</h5>
				 <form method="post">
				 	<div class="form-group">
				 		<label>Student Id</label>
				 		<input type="number" name="did" class="form-control" autocomplete="off" placeholder="Enter Student Id">
				 	</div>
				 	<div class="form-group">
				 		<label>Student Name</label>
				 		<input type="text" name="sname" class="form-control" autocomplete="off" placeholder="Enter Student Name">
				 	</div>
				 	<div class="form-group">
				 		<label>Password</label>
				 		<input type="password" name="pass" class="form-control" autocomplete="off" placeholder="Enter Your Password">
				 	</div>
				 	<div class="form-group">
				 		<label>Date Of Birth</label>
				 		<input type="date" name="dob" class="form-control" autocomplete="off">
				 	</div>
				 	<div class="form-group">
				 		<label>Gender</label>
				 		<select name="gender" class="form-control">
				 			<option value="">Select Your Gender</option>
				 			<option value="Male">Male</option>
				 			<option value="Female">Female</option>
				 		</select>
				 	</div>
				 	<div class="form-group">
				 		<label>Blood Group</label>
				 		<input type="text" name="blood" class="form-control" autocomplete="off" placeholder="Enter Your Blood Group">
				 	</div>
				 	<div class="form-group">
				 		<label>Physically Challenged</label>
				 		<select name="phy" class="form-control">
				 			<option value="no">NO</option>
				 			<option value="yes">YES</option>
				 		</select>
				 	</div>
				 	<div class="form-group">
				 		<label>First Graduate</label>
				 		<select name="first" class="form-control">
				 			<option value="no">NO</option>
				 			<option value="yes">YES</option>
				 		</select>
				 	</div>
				 	<div class="form-group">
				 		<label>Community</label>
				 		<input type="text" name="com" class="form-control" autocomplete="off" placeholder="Enter Your Community">
				 	</div>
				 	<div class="form-group">
				 		<label>Religion</label>
				 		<input type="text" name="rel" class="form-control" autocomplete="off" placeholder="Enter Your Religion">
				 	</div>
				 	<div class="form-group">
				 		<label>Mother Tongue</label>
				 		<input type="text" name="mom" class="form-control" autocomplete="off" placeholder="Enter Your Mother Tongue">
				 	</div>
				 	<div class="form-group">
				 		<label>Aadhar Number</label>
				 		<input type="number" name="anum" class="form-control" autocomplete="off" placeholder="Enter Aadhar Number">
				 	</div>
				 	<div class="form-group">
				 		<label>Nationality</label>
				 		<input type="text" name="nation" class="form-control" autocomplete="off" placeholder="Enter Your Nationality">
				 	</div>
				 	<div class="form-group">
				 		<label>Address</label>
				 		<input type="text" name="add" class="form-control" autocomplete="off" placeholder="Enter Your Address">
				 	</div>
				 	<div class="form-group">
				 		<label>City</label>
				 		<input type="text" name="city" class="form-control" autocomplete="off" placeholder="Enter Your City">
				 	</div>
				 	<div class="form-group">
				 		<label>District</label>
				 		<input type="text" name="dis" class="form-control" autocomplete="off" placeholder="Enter Your District">
				 	</div>
				 	<div class="form-group">
				 		<label>State</label>
				 		<input type="text" name="st" class="form-control" autocomplete="off" placeholder="Enter Your State">
				 	</div>
				 	<div class="form-group">
				 		<label>Pincode</label>
				 		<input type="number" name="pin" class="form-control" autocomplete="off" placeholder="Enter Your Pincode">
				 	</div>
				 	<div class="form-group">
				 		<label>Email</label>
				 		<input type="text" name="email" class="form-control" autocomplete="off" placeholder="Enter E-mail Address">
				 	</div>
				 	<div class="form-group">
				 		<label>Phone</label>
				 		<input type="number" name="phone" class="form-control" autocomplete="off" placeholder="Enter Phone Number">
				 	</div>
				 	<input type="submit" name="create" class="btn btn-success my-3" value="Create Account">
				 	<p><b>I already have an account</b><a href="../student/login.php" ><kbd class="text text-info">Click here.</kbd></a></p>
				 </form>
				 <ul class="pagination justify-content-middle">
    					<li class="page-item active">
      						<a class="page-link" href="../student/family.php" tabindex="-1">Previous</a>
    					</li>
    				<li class="page-item"><a class="page-link" href="../student/login.php">1</a></li>
   					<li class="page-item"><a class="page-link" href="../student/education.php">2</a></li>
    				<li class="page-item"><a class="page-link" href="../student/family.php">3</a></li>
                    <li class="page-item active">
                      <a class="page-link" href="../student/login.php">Next</a>
                    </li>
                </ul>
                 <code style="font-size: 25px">&it;&gt;If you already have an account directly go to the login page&it;&gt;</code>
			</div>
			<div class="col-md-3"></div>
		</div>
	</div>
</div>
</body>
</html>

