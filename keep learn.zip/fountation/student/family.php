<!DOCTYPE html>
<?php  
session_start();
include("../login/connection.php");
if(isset($_POST['create'])){
	$Student_ID=$_POST['stu_id'];
	$No_Of_earning_members=$_POST['earningmember'];
	$Total_Annual_income=$_POST['totalannual'];
    $Father_name=$_POST['father'];
    $Father_Qualification=$_POST['fqual'];
    $Father_Occupation=$_POST['foccu'];
    $Father_annual_income=$_POST['fannual'];
    $Mother_name=$_POST['mother'];
    $Mother_Qualification=$_POST['mothqual'];
    $Mother_Occupation=$_POST['maoccupa'];
    $Mother_annual_income=$_POST['mannual'];
    $No_Of_Siblings=$_POST['sib'];
	$error=array();
	if(empty($Student_ID)){
		$error['ac']="Enter Student_ID";
	}
	elseif (empty($No_Of_earning_members)) {
		$error['ac']="Enter No_Of_earning_members";
	}
	elseif (empty($Total_Annual_income)) {
		$error['ac']="Enter Total_Annual_income";
	}
	elseif (empty($Father_name)) {
		$error['ac']="Enter Father_name";
	}
	elseif (empty($Father_Qualification)) {
		$error['ac']="Enter Father_Qualification";
	}
	elseif (empty($Father_Occupation)) {
		$error['ac']="Enter Father_Occupation";
	}
	elseif (empty($Father_annual_income)) {
		$error['ac']="Enter Father_annual_income";
	}
	elseif (empty($Mother_name)) {
		$error['ac']="Select Mother_name";
	}
	elseif (empty($Mother_Qualification)) {
		$error['ac']="Enter Mother_Qualification";
	}
	elseif (empty($Mother_Occupation)) {
		$error['ac']="Enter Admission_Status";
	}
	elseif (empty($Mother_annual_income)) {
		$error['ac']="Enter mother annual income";
	}
	elseif (empty($No_Of_Siblings)) {
		$error['ac']="Enter no of siblings";
	}
	if(count($error)==0){
		$query="INSERT INTO `family`(`id`, `no of earning members`, `annual income`, `father name`, `father qualification`, `father occupation`, `father income`, `mother name`, `mother qulification`, `mother occupation`, `mother income`, `no of sibing`) VALUES ('','$Student_ID','$No_Of_earning_members','$Total_Annual_income',' $Father_name','$Father_Qualification','$Father_Occupation','$Father_annual_income','$Mother_name',
		'$Mother_Qualification','$Mother_Occupation','$Mother_annual_income','$No_Of_Siblings')";
		$res=mysqli_query($conn,$query);
		if($res){
			header('Location:../student/login.php');
		}
		else{
			echo "<script>alert('failed')</script>";
		}
	}
}

?>
<html>
<head>
	<title>Family Details</title>
</head>
<body>
<?php  
include("../login/header.php");
?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6 my-5 jumbotron">
				 <h5 class="text-center my-3">Family Details</h5>
				 <form method="post">
				 	<div class="form-group">
				 		<label>Student_ID</label>
				 		<input type="text" name="stu_id" class="form-control" autocomplete="off" placeholder="Enter Student_ID" required>
				 	</div>
				 	<div class="form-group">
				 		<label>No_Of_earning_members</label>
				 		<input type="text" name="earningmember" class="form-control" autocomplete="off" placeholder="Enter No_Of_earning_members" required>
				 	</div>
				 	<div class="form-group">
				 		<label>Total_Annual_income</label>
				 		<input type="text" name="totalannual" class="form-control" autocomplete="off" placeholder="Enter Total_Annual_income" required>
				 	</div>
				 	<div class="form-group">
				 		<label>Father_name</label>
				 		<input type="text" name="father" class="form-control" autocomplete="off" placeholder="Enter Father_name" required>
				 	</div>
				 	<div class="form-group">
				 		<label>Father_Qualification</label>
				 		<input type="text" name="fqual" class="form-control" autocomplete="off" placeholder="Enter Father_Qualification" required>
				 	</div>
				 	<div class="form-group">
				 		<label>Father_Occupation</label>
				 		<input type="text" name="foccu" class="form-control" autocomplete="off" placeholder="Enter Father_Occupation" required>
				 	</div>
				 	<div class="form-group">
				 		<label>Father_annual_income</label>
				 		<input type="text" name="fannual" class="form-control" autocomplete="off" placeholder="Enter Father_annual_income" required>
				 	</div>
				 	<div class="form-group">
				 		<label>Mother_name</label>
				 		<input type="text" name="mother" class="form-control" autocomplete="off" placeholder="Enter Mother_name">
				 	</div>
				 	<div class="form-group">
				 		<label>Mother_Qualification</label>
				 		<input type="text" name="mothqual" class="form-control" autocomplete="off" placeholder="Enter $Mother_Qualification" required>
				 	</div>
				 	<div class="form-group">
				 		<label> Mother_Occupation</label>
				 		<input type="text" name="maoccupa" class="form-control" autocomplete="off" placeholder="Enter Mother_Occupation" required>
				 	</div>
				 	<div class="form-group">
				 		<label>Mother_annual_income</label>
				 		<input type="text" name="mannual" class="form-control" autocomplete="off" placeholder="Enter Mother_annual_income" required>
				 	</div>
				 	<div class="form-group">
				 		<label>No_Of_Siblings</label>
				 		<input type="text" name="sib" class="form-control" autocomplete="off" placeholder="Enter No_Of_Siblings" required>
				 	</div>
				 	<input type="submit" name="create" class="btn btn-success my-3" value="Create Account">
				 	<p>I already have an account <a href="patientlogin.php" >Click here.</a></p>
				 </form>
				 <ul class="pagination justify-content-middle">
    					<li class="page-item active">
      						<a class="page-link" href="../student/education.php" tabindex="-1">Previous</a>
    					</li>
    				<li class="page-item"><a class="page-link" href="../student/login.php">1</a></li>
   					<li class="page-item"><a class="page-link" href="../student/education.php">2</a></li>
    				<li class="page-item"><a class="page-link" href="../student/account.php">3</a></li>
                    <li class="page-item active">
                      <a class="page-link" href="../student/account.php">Next</a>
                    </li>
                </ul>
			</div>
			<div class="col-md-3"></div>
		</div>
	</div>
</div>
</body>
</html>

