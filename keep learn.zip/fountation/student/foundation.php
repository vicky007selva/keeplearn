<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php  
include("../login/header.php");
?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
		<div class="col-md-2 " style="margin-left: -30px;">
			<?php
				include("sidenav.php");
				include("../login/connection.php");
			  ?>
		</div>
		<div class="col-md-10">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
						<h5 class="text-center">All Foundation</h5>
						<?php 
						$query="SELECT * FROM found";
					$res=mysqli_query($conn,$query);
					$output="
					
					<table class= 'table table-bordered'>
							<tr><th>Id</th>
							<th>State</th>
							<th>District</th>
							<th>Organization name</th>
							<th>Email</th>
							<th>Address</th>
							<th>Phone</th>
							<th>Schemes</th>
							<th>Authorized Person</th>
					</tr>";
					if(mysqli_num_rows($res)<1){
						$output.="<tr><td colspan='2'   class=text-center >No New Patient</td></tr>";
					}
					else{
					while ($row=mysqli_fetch_assoc($res)) {
						$id=$row['id'];
						$st=$row['STATE'];
						$dis=$row['DISTRICT'];
						$org=$row['ORGANIZATION NAME'];
						$email=$row['EMAIL'];
						$add=$row['ADDRESS'];
						$phone=$row['PHONE NUMBER'];
						$scheme=$row['SCHEMES'];
						$per=$row['AUTHORIZED PERSON'];
						$output.="
						<tr>
								<td>$id</td>
								<td>$st</td>
								<td>$dis</td>
								<td>$org</td>
								<td>$email</td>
								<td>$add</td>
								<td>$phone</td>
								<td>$scheme</td>
								<td>$per</td>
						";
					}
					}
					$output.="<tr></tr>
						</table>";
					echo "$output";
						?>

					</div>
					<div class="col-md-6">
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</body>
</html>