<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
     <title></title>
</head>
<body style="background:url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtJM3k-m5EA5mUVXux-Gqt_YPVjyTcTzfm8g&usqp=CAU); ">
<?php 
 include("../login/connection.php"); 
include("../login/header.php");
?>
<div class="container-fluid">
                              <?php 
                              $exam=$_SESSION['exam'];
                              $query="SELECT * FROM exam WHERE exam_name='$exam'";
                         $res=mysqli_query($conn,$query);
                              ?>
                            <h1 class="text-center">Exam Details</h1>
                            <?php  
                             $exam=$_SESSION['exam'];
                              $query="SELECT * FROM exam WHERE exam_name='$exam'";
                         $res=mysqli_query($conn,$query);
                          $row=mysqli_fetch_assoc($res);
                            ?>
                              <h3>What is Exam id?</h3>
                              <p>Exam id is based on the college. By searching this using this id tou can fetch all information about exam when it will be connected venue and etc</p>
                              <h3>For this college exam id is <kbd><?php echo $row['id'];  ?></kbd></h3> 
                              <h3>What is Degree</h3>
                              <p>Here you can study some possible degree by attending online exam and getting seats for whatever course you want to do</p>
                              <p>By geting good percentage in entrence exam you choose this preferable courses<h3><kbd ><?php echo $row['degree'];  ?></kbd></h3></p> 
                              <h3>What is eligibility?</h3>
                              <p>Eligibility is nothing but are you able to handle the specific Degree or course</p>
                              <h4>Here eligibility criteria is</h4>
                              <p>Candidates should have passed class 12 or qualifying the exam in 2019 or 2020. Candidates appearing in class 12 or equivalent qualifying exam in 2021 can also apply for <h3><kbd ><?php echo $row['exam_name'];  ?></kbd> </h3></p>
                              <h3>Application Link</h3>
                              <p>By using this link you can apply for this exam and also get futher more details about exam and when it will be conducted.you get more details about particular college
                          </p>
                          <h3><kbd><a href="www.jeemain.nic.in"></a><?php echo $row['link'];  ?></kbd></h3>
                              </div>
</body>
</html>