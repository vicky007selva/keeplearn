<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
				<!--sidenav-->
				<div class="list-group bg-dark" style="height:90vh ">
					<a href="index.php" class="list-group-item list-group-item-action bg-dark text-center text-warning">Dashboard</a>
					<a href="profile.php" class="list-group-item list-group-item-action bg-dark text-center text-warning">Profile</a>
					<a href="donors.php" class="list-group-item list-group-item-action bg-dark text-center text-warning">Donars</a>
					<a href="cexam.php" class="list-group-item list-group-item-action bg-dark text-center text-warning">All exams</a>
					<a href="#" class="list-group-item list-group-item-action bg-dark text-center text-warning">Schoolership</a>
				</div>

</body>
</html>