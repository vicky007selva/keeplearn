<?php  
$dbHost="localhost";
$dbUser="root";
$dbPass="";
$dbName="lms";

$conn=mysqli_connect($dbHost,$dbUser,$dbPass,$dbName);
/*if($conn){
	echo "connected successfully";
}
else{
	echo "connection Failed";
}*/
?>
